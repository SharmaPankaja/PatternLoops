package PatternPackage;

public class AlphabetPattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a='A';
		for(int i=0;i<=5;i++)
		{
			for(int j=0;j<=5;j++)
			{
				System.out.print((char)(a+i+j)+" ");
			}
			System.out.println();
		}


	}

}
