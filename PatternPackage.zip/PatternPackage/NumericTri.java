package PatternPackage;

public class NumericTri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row=5;
		int col=1;
		for (int i = 1; i <= row; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(" " + i + " ");
			}
			System.out.println();
		}

		System.out.println("======================================");

		for (int i = 1; i <= row; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(" " + j + " ");
			}
			System.out.println();
		}
		
		System.out.println("======================================");

		for (int i = 1; i <= row; i++) {
			for (int j = 1; j <= i; j++) {
				if(i%2==0)
					System.out.print(" 0 ");
				else
					System.out.print(" 1 ");
			}
			System.out.println();
		}
		
		System.out.println("======================================");

		for (int i = 1; i <= row; i++) {
			for (int j = 1,k=i; j <= i; j++) {
				System.out.print(k++);
			}
			System.out.println();
		}


	}

}
