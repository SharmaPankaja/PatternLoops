package PatternPackage;

public class NumericTri2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		for (int i =1; i <= 6; i++) {

			for (int k = 1; k <=i; k++) {
				System.out.print(" ");
			}
			for (int l = i; l <=6; l++) {
				System.out.print(l+" ");

			}
			
			System.out.println();

		}
		

		

	}


}
