package PatternPackage;

public class StarTri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int row = 5;
		int col = 1,space=1,star=5;
		for (int i = 1; i <= row; i++) {
			for (int j = 1; j <= i; j++) {
				System.out.print(" * ");
			}
			System.out.println();
		}

		System.out.println("======================================");

		for(int i=0;i<5;i++)
		{
			for(int j=0;j<space;j++)
			{
				for(int k=0;k<=star;k++)
					System.out.print(" * ");
			}
			System.out.println();
		}space++;
		star--;
		
		//System.out.println();
	}
	

}
